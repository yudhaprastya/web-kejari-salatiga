<footer class="main-footer">
    <strong>Developed @ 2024.</strong>
    <div class="float-right d-none d-sm-inline-block">
    by <a href="https://adminlte.io">Yudha (Monsterup)</a>
    </div>
</footer>